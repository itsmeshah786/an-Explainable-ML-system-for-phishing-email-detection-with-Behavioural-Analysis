
import pandas as pd
import numpy as np
import re
import nltk
import subprocess
import sys
import os
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from textblob import TextBlob

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.preprocessing import StandardScaler          # FIX 1: scale behavioural features

import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st

# --------- NLTK Setup ----------
nltk.download('stopwords', quiet=True)
nltk.download('wordnet', quiet=True)
nltk.download('omw-1.4', quiet=True)

stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

# --------- Behavioural Lexicons ----------
# FIX 2: Expanded lexicons — more coverage of real phishing vocabulary
URGENCY_WORDS = [
    "urgent", "urgently", "immediately", "now", "verify", "suspend", "suspended",
    "expire", "expiring", "expired", "action required", "limited time",
    "final notice", "last chance", "act now", "respond immediately",
    "account locked", "access denied", "warning", "alert", "critical",
    "deadline", "overdue", "past due", "confirm immediately", "reactivate"
]

AUTHORITY_WORDS = [
    "admin", "administrator", "security", "security team", "support",
    "bank", "account team", "it department", "hr", "manager",
    "helpdesk", "service desk", "compliance", "fraud team",
    "paypal", "microsoft", "apple", "google", "amazon",
    "your provider", "system administrator", "customer service",
    "technical support", "official notice", "headquarters"
]

# --------- Custom Transformers ----------
class BehaviouralExtractor(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        features = []
        for text in X:
            text_lower = str(text).lower()
            u_score = sum(1 for w in URGENCY_WORDS if w in text_lower)
            a_score = sum(1 for w in AUTHORITY_WORDS if w in text_lower)
            sent    = TextBlob(text_lower).sentiment.polarity

            # FIX 3: Add extra engineered signals
            exclaim_count  = text_lower.count('!')            # urgency signal
            caps_ratio     = sum(1 for c in str(text) if c.isupper()) / max(len(str(text)), 1)
            link_count     = len(re.findall(r'http|www|click here|login|sign in', text_lower))

            features.append([u_score, a_score, sent, exclaim_count, caps_ratio, link_count])
        return np.array(features)


class TextCleaner(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        cleaned = []
        for text in X:
            text = str(text).lower()
            text = re.sub(r"http\S+", " url ", text)
            text = re.sub(r"[^a-z\s]", " ", text)
            tokens = [lemmatizer.lemmatize(w) for w in text.split() if w not in stop_words]
            cleaned.append(" ".join(tokens))
        return cleaned


# --------- Load & Prepare Data ----------
@st.cache_data
def load_and_prepare_data(path="emails.csv"):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Dataset not found at {path}")

    df = pd.read_csv(path)

    y     = df['Prediction']
    X_raw = df.drop(['Email No.', 'Prediction'], axis=1)

    df['text_reconstructed'] = X_raw.apply(
        lambda row: ' '.join(
            (str(col) + ' ') * int(val)
            for col, val in row.items() if val > 0
        ), axis=1
    )

    X_train_text, X_test_text, y_train, y_test = train_test_split(
        df['text_reconstructed'], y,
        test_size=0.2, stratify=y, random_state=42
    )

    # ── Build the improved hybrid pipeline ───────────────────────────────
    pipeline = Pipeline([
        ('features', FeatureUnion([

            ('tfidf', Pipeline([
                ('cleaner',    TextCleaner()),
                # FIX 4: More TF-IDF features + sublinear_tf dampens dominant terms
                ('vectorizer', TfidfVectorizer(
                    ngram_range=(1, 2),
                    max_features=2000,          # up from 1000
                    sublinear_tf=True,          # log-scale term frequency
                    min_df=2,                   # ignore very rare tokens
                    max_df=0.95                 # ignore near-universal tokens
                ))
            ])),

            # FIX 1: Wrap BehaviouralExtractor in a StandardScaler so
            # its values match the 0–1 range of TF-IDF and are not drowned out
            ('behaviour', Pipeline([
                ('extractor', BehaviouralExtractor()),
                ('scaler',    StandardScaler())
            ]))

        ])),

        # FIX 5: class_weight='balanced' corrects the 71/29 class imbalance
        # FIX 6: More trees + min_samples_leaf reduces overfitting
        ('clf', RandomForestClassifier(
            n_estimators=200,           # up from 100
            class_weight='balanced',    # corrects 71% safe / 29% phishing imbalance
            min_samples_leaf=2,         # prevents overfitting on rare patterns
            random_state=42
        ))
    ])

    pipeline.fit(X_train_text, y_train)

    y_pred = pipeline.predict(X_test_text)
    report = classification_report(y_test, y_pred, output_dict=True)
    cm     = confusion_matrix(y_test, y_pred)

    return {
        "pipeline":    pipeline,
        "X_test_text": X_test_text.values,
        "y_test":      y_test.values,
        "report":      report,
        "cm":          cm,
        "df":          df
    }


# --------- Streamlit GUI ----------
def run_app():
    st.set_page_config(page_title="Phishing XAI Detector", layout="wide")
    st.title("🛡️ Behaviour-Driven Phishing Detection (XAI)")

    st.sidebar.header("Settings")
    data_path = st.sidebar.text_input("Dataset Path", "emails.csv")

    try:
        with st.spinner("Analysing dataset and training model..."):
            data = load_and_prepare_data(data_path)

        pipeline     = data["pipeline"]
        report       = data["report"]
        cm           = data["cm"]
        X_test_text  = data["X_test_text"]

        tab1, tab2, tab3 = st.tabs(["📊 Performance", "📧 Analysis", "📈 XAI Dashboard"])

        # ── Tab 1: Performance ────────────────────────────────────────────
        with tab1:
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Model Accuracy", f"{report['accuracy']*100:.2f}%")
                st.dataframe(pd.DataFrame(report).transpose())
            with col2:
                fig_cm, ax_cm = plt.subplots()
                sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax_cm)
                ax_cm.set_title("Confusion Matrix")
                st.pyplot(fig_cm)

        # ── Tab 2: Analysis ───────────────────────────────────────────────
        with tab2:
            st.subheader("Explain Classification")
            email_input = st.text_area("Paste email content to analyse:", height=150)

            if st.button("Analyse Email"):
                if email_input:
                    from lime.lime_text import LimeTextExplainer

                    proba = pipeline.predict_proba([email_input])[0]
                    pred  = pipeline.predict([email_input])[0]

                    # FIX 7: Show probability as percentage, not raw decimal
                    st.write(f"### Result: {'🚨 PHISHING' if pred == 1 else '✅ SAFE'}")

                    col_a, col_b = st.columns(2)
                    with col_a:
                        st.metric("Safe Probability",     f"{proba[0]*100:.1f}%")
                    with col_b:
                        st.metric("Phishing Probability", f"{proba[1]*100:.1f}%")

                    st.progress(float(proba[1]))

                    # FIX 8: Increase num_features from 10 to 15 for richer explanation
                    explainer = LimeTextExplainer(class_names=["Safe", "Phishing"])
                    exp = explainer.explain_instance(
                        email_input,
                        pipeline.predict_proba,
                        num_features=15,
                        num_samples=1000        # more samples = more stable explanation
                    )
                    st.components.v1.html(exp.as_html(), height=550, scrolling=True)

                    # FIX 9: Show plain-language behavioural breakdown
                    st.subheader("Behavioural Feature Breakdown")
                    text_lower = email_input.lower()
                    u_hits = [w for w in URGENCY_WORDS  if w in text_lower]
                    a_hits = [w for w in AUTHORITY_WORDS if w in text_lower]
                    sent   = TextBlob(text_lower).sentiment.polarity

                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Urgency Score",   len(u_hits))
                        if u_hits:
                            st.caption("Triggered: " + ", ".join(u_hits))
                    with col2:
                        st.metric("Authority Score", len(a_hits))
                        if a_hits:
                            st.caption("Triggered: " + ", ".join(a_hits))
                    with col3:
                        st.metric("Sentiment Polarity", f"{sent:.2f}")
                        st.caption("−1 = very negative  ·  +1 = very positive")

                else:
                    st.warning("Please paste an email before clicking Analyse.")

        # ── Tab 3: XAI Dashboard ──────────────────────────────────────────
        with tab3:
            st.subheader("Feature Importance")
            importances = pipeline.named_steps['clf'].feature_importances_
            # Show importance of the last 6 (Behavioural) features
            st.write("Impact of Behavioural Scores (Urgency, Authority, Sentiment, Exclamation, Caps, Links):")
            st.bar_chart(importances[-6:])

    except Exception as e:
        st.error(f"Error: {e}")
        st.exception(e)


# --------- Execution Logic ----------
if __name__ == "__main__":
    if st.runtime.exists():
        run_app()
    else:
        print("Launching Streamlit Server...")
        subprocess.run([sys.executable, "-m", "streamlit", "run", __file__])
