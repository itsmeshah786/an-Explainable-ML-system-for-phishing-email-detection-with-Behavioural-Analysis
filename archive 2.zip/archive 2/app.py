
import pandas as pd
import numpy as np
import re
import nltk
import subprocess
import sys
import os
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from textblob import TextBlob

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline, FeatureUnion

import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st

# --------- NLTK Setup ----------
nltk.download('stopwords', quiet=True)
nltk.download('wordnet', quiet=True)
nltk.download('omw-1.4', quiet=True)

stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

# --------- Behavioural Lexicons ----------
URGENCY_WORDS = ["urgent", "immediately", "now", "verify", "suspend", "expire", "action required", "limited time"]
AUTHORITY_WORDS = ["admin", "security", "support", "bank", "account team", "it department", "hr", "manager"]

# --------- Custom Transformers ----------
class BehaviouralExtractor(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        features = []
        for text in X:
            text_lower = str(text).lower()
            u_score = sum(1 for w in URGENCY_WORDS if w in text_lower)
            a_score = sum(1 for w in AUTHORITY_WORDS if w in text_lower)
            sent = TextBlob(text_lower).sentiment.polarity
            features.append([u_score, a_score, sent])
        return np.array(features)

class TextCleaner(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        cleaned = []
        for text in X:
            text = str(text).lower()
            text = re.sub(r"http\S+", " url ", text)
            text = re.sub(r"[^a-z\s]", " ", text)
            tokens = [lemmatizer.lemmatize(w) for w in text.split() if w not in stop_words]
            cleaned.append(" ".join(tokens))
        return cleaned

# --------- Load & Prepare Data ----------
@st.cache_data
def load_and_prepare_data(path="emails.csv"):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Dataset not found at {path}")
        
    df = pd.read_csv(path)
    
    # Since the CSV (emails.csv) uses word counts as columns, 
    # we reconstruct a 'text' representation for the NLP pipeline to work.
    # We'll use the 'Prediction' as target.
    y = df['Prediction']
    X_raw = df.drop(['Email No.', 'Prediction'], axis=1)
    
    # Create a string representation from the word-count columns for the pipeline
    # This allows LIME to 'perturb' the text naturally.
    df['text_reconstructed'] = X_raw.apply(lambda row: ' '.join((str(col) + ' ') * int(val) for col, val in row.items() if val > 0), axis=1)
    
    X_train_text, X_test_text, y_train, y_test = train_test_split(
        df['text_reconstructed'], y, test_size=0.2, stratify=y, random_state=42
    )

    # Build the hybrid pipeline
    pipeline = Pipeline([
        ('features', FeatureUnion([
            ('tfidf', Pipeline([
                ('cleaner', TextCleaner()),
                ('vectorizer', TfidfVectorizer(ngram_range=(1, 2), max_features=1000))
            ])),
            ('behaviour', BehaviouralExtractor())
        ])),
        ('clf', RandomForestClassifier(n_estimators=100, random_state=42))
    ])

    pipeline.fit(X_train_text, y_train)
    
    y_pred = pipeline.predict(X_test_text)
    report = classification_report(y_test, y_pred, output_dict=True)
    cm = confusion_matrix(y_test, y_pred)

    return {
        "pipeline": pipeline,
        "X_test_text": X_test_text.values,
        "y_test": y_test.values,
        "report": report,
        "cm": cm,
        "df": df
    }

# --------- Streamlit GUI ----------
def run_app():
    st.set_page_config(page_title="Phishing XAI Detector", layout="wide")
    st.title("🛡️ Behaviour-Driven Phishing Detection (XAI)")
    
    st.sidebar.header("Settings")
    data_path = st.sidebar.text_input("Dataset Path", "emails.csv")

    try:
        with st.spinner("Analysing dataset and training model..."):
            data = load_and_prepare_data(data_path)
        
        pipeline = data["pipeline"]
        report = data["report"]
        cm = data["cm"]
        X_test_text = data["X_test_text"]

        tab1, tab2, tab3 = st.tabs(["📊 Performance", "📧 Analysis", "📈 XAI Dashboard"])

        with tab1:
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Model Accuracy", f"{report['accuracy']*100:.2f}%")
                st.dataframe(pd.DataFrame(report).transpose())
            with col2:
                fig_cm, ax_cm = plt.subplots()
                sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax_cm)
                ax_cm.set_title("Confusion Matrix")
                st.pyplot(fig_cm)

        with tab2:
            st.subheader("Explain Classification")
            email_input = st.text_area("Paste email content to analyse:", height=150)
            
            if st.button("Analyse Email"):
                if email_input:
                    # Logic for LIME & Prediction
                    from lime.lime_text import LimeTextExplainer
                    
                    proba = pipeline.predict_proba([email_input])[0]
                    pred = pipeline.predict([email_input])[0]
                    
                    st.write(f"### Result: {'🚨 PHISHING' if pred == 1 else '✅ SAFE'}")
                    st.progress(proba[1])
                    
                    explainer = LimeTextExplainer(class_names=["Safe", "Phishing"])
                    exp = explainer.explain_instance(email_input, pipeline.predict_proba, num_features=10)
                    st.components.v1.html(exp.as_html(), height=500, scrolling=True)

        with tab3:
            st.subheader("Feature Importance")
            importances = pipeline.named_steps['clf'].feature_importances_
            # Show importance of the last 3 (Behavioural) features
            st.write("Impact of Behavioural Scores (Urgency, Authority, Sentiment):")
            st.bar_chart(importances[-3:])

    except Exception as e:
        st.error(f"Error: {e}")

# --------- Execution Logic ----------
if __name__ == "__main__":
    # Check if we are running inside Streamlit
    if st.runtime.exists():
        run_app()
    else:
        # If running as 'python app.py', launch the streamlit server
        print("Launching Streamlit Server...")
        subprocess.run([sys.executable, "-m", "streamlit", "run", __file__])